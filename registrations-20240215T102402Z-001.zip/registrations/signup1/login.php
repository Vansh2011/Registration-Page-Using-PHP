<?php
$login=0;
$invalid=0;
if ($_SERVER['REQUEST_METHOD']=='POST'){
  include 'connect.php';
  $username = $_POST['username'];
  $email = $_POST['email'];
  $password = $_POST['password'];


  $sql = "select * from registration where username= '$username' and email='$email' and password='$password'";
  $result = mysqli_query($con,$sql);
  if($result){
    $num = mysqli_num_rows($result);
    if($num>0){
      $login=1;
      session_start();
      $_SESSION['username']=$username;
      header('location:home.php');
    }else{
      $invalid = 1;
      }
    }
  }
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link
      href="bootstrap-5.0.2-dist/css/bootstrap.min.css"
      rel="stylesheet"
      type="text/CSS"
    />

  <title>Login Page</title>
</head>
<body>
<?php
    if($invalid){
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Holy guacamole!</strong> You should check in on fields you still are not the part of this page.
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}
  ?>
  <?php
    if($login){
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Welcome Back!</strong> You are allowed on the page. Welcome Aboard!
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';}
  ?>

  <div class="container my-5">
  <h1 class="text-center">Login Page</h1>
  <form action="login.php" method="post">
  <div class="form-group mb-3">
    <label for="username" class="form-label">Username</label>
    <input type="text" class="form-control" name="username" placeholder="Enter your Username" aria-describedby="emailHelp">
  </div>
  <div class="form-group mb-3">
    <label for="exampleInputEmail1" class="form-label">Email ID</label>
    <input type="email" class="form-control" name="email" placeholder="Enter your Email ID" aria-describedby="emailHelp">
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>
  <div class="form-group mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" placeholder="Enter your password" name="password">
  </div>
  <div class="text-center">
  <button type="submit" class="btn btn-primary text">Login</button>
  <button type="submit" class="btn btn-primary text">Register</button>
  </div>
</form>
  </div>
  
</body>
</html>