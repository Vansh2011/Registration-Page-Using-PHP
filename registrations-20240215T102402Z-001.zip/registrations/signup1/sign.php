<?php
$succ=0;
$user=0;
if ($_SERVER['REQUEST_METHOD']=='POST'){
  include 'connect.php';
  $username = $_POST['username'];
  $email = $_POST['email'];
  $password = $_POST['password'];


  $sql = "select * from registration where username= '$username'";
  $result = mysqli_query($con,$sql);
  if($result){
    $num = mysqli_num_rows($result);
    if($num>0){
      // echo "User Already Exists";
      $user=1;
    }else{
      $sql = "insert into registration(username,email,password)
      values('$username','$email','$password')";
      $result = mysqli_query($con,$sql);
      if($result){
        // echo "Signup Successful";
        $succ=1;
      }
    }
  }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link
      href="bootstrap-5.0.2-dist/css/bootstrap.min.css"
      rel="stylesheet"
      type="text/CSS"
    />

  <title>Sign Up Form</title>
</head>
<body>
  <?php
    if($user){
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Holy guacamole!</strong> You should check in on the username this person already exists.
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}
  ?>
  <?php
    if($succ){
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Well Done!</strong> You are finally registered with us. Welcome Aboard!
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';}
  ?>
  <div class="container my-5">
  <h1 class="text-center">Sign Up Page</h1>
  <form action="sign.php" method="post">
  <div class="form-group mb-3">
    <label for="username" class="form-label">Username</label>
    <input type="text" class="form-control" name="username" placeholder="Enter your Username" aria-describedby="emailHelp">
  </div>
  <div class="form-group mb-3">
    <label for="exampleInputEmail1" class="form-label">Email ID</label>
    <input type="email" class="form-control" name="email" placeholder="Enter your Email ID" aria-describedby="emailHelp">
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>
  <div class="form-group mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" placeholder="Enter your password" name="password">
  </div>
  <div class="text-center">
  <button type="submit" class="btn btn-primary text">Sign Up</button>
  <button type="submit" class="btn btn-primary text">Login</button>
  </div>
</form>
  </div>
  
</body>
</html>