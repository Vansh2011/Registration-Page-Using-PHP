<?php 
	$con=mysqli_connect("localhost","root","","signupform");
	if(!$con)
	// {
		echo "Connection is not Successful.";
	// }else{
  //   echo "Connection Successful";
  // }
?>